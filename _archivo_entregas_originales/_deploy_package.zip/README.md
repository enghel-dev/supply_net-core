# SupplyNet — Hackathon Nicaragua 2026

Plataforma que conecta proveedores de insumos/materia prima/servicios con
compradores (MiPymes, emprendedores) — reto "Plataforma de Proveedores y
productos finales" / "Conecta Emprende".

## Estructura del proyecto

```
SupplyNet/
├── docker-compose.yml        # Orquesta todos los servicios
├── .env.example               # Variables de entorno (copiar a .env)
├── services/
│   ├── db/                    # PostgreSQL — entregado por Dev 1
│   │   ├── init/               # Scripts que Postgres corre al iniciar
│   │   └── schema/              # Schema SQL (fuente de verdad)
│   ├── redis/                 # Cache de lecturas
│   ├── backend/                # API — pendiente de entrega
│   └── frontend/               # Cliente web — pendiente de entrega
└── scripts/
    └── db-reset.sh             # Helper para reiniciar la DB local
```

Cada servicio vive en su propia carpeta bajo `services/`, con su propio
`README.md` explicando qué contiene y cómo se conecta con los demás.

## Cómo levantar el proyecto

1. Copia el archivo de variables de entorno:
   ```bash
   cp .env.example .env
   ```
2. Levanta lo que ya está listo (db + redis):
   ```bash
   docker compose up -d
   ```
3. Verifica que todo esté sano:
   ```bash
   docker compose ps
   docker compose logs -f db
   ```
   Deberías ver en los logs algo como:
   `[supplynet-db-init] No se encontró el schema. Aplicando /sql/01-schema.sql ...`
   seguido de `Schema aplicado correctamente.` — eso solo pasa la primera vez.
   Si vuelves a hacer `docker compose restart db` o `down` + `up` (sin borrar
   el volumen), verás en su lugar:
   `[supplynet-db-init] La tabla 'usuarios' ya existe...` — es decir, no se
   vuelve a ejecutar el schema.

## Servicios

| Servicio | Estado | Puerto local | Notas |
|---|---|---|---|
| `db` (Postgres 16) | ✅ Listo | 5432 | Schema de Dev 1, con init condicional |
| `redis` (Redis 7) | ✅ Listo | 6379 | Cache de lecturas (catálogo, búsquedas) |
| `backend` | ⏳ Pendiente | 3000 (sugerido) | Bloque comentado en `docker-compose.yml`, listo para descomentar |
| `frontend` | ⏳ Pendiente | 5173 (sugerido) | Bloque comentado en `docker-compose.yml`, listo para descomentar |

## Por qué Redis

Se agregó Redis como cache de lecturas frecuentes (listados de productos,
categorías, búsquedas de proveedores cercanos) para no golpear Postgres en
cada request del frontend. Ver `services/redis/README.md` para el patrón
de uso recomendado (cache-aside) y qué keys cachear.

## Cuando lleguen los demás devs

1. El dev de backend deja su código + `Dockerfile` en `services/backend/`.
2. El dev de frontend deja su código + `Dockerfile` en `services/frontend/`.
3. Se descomentan los bloques correspondientes en `docker-compose.yml`.
4. `docker compose up -d --build`.

Ambos servicios ya quedan pre-configurados para conectarse a `db` y
`redis` por nombre de servicio (red interna de Docker), usando las
variables `DATABASE_URL` / `REDIS_URL` — no hace falta hardcodear hosts.

## Reiniciar la base de datos local desde cero

```bash
./scripts/db-reset.sh
```

Esto borra el volumen de Postgres y fuerza a que el init se vuelva a
correr (porque el volumen queda vacío otra vez).
